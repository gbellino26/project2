from django.contrib import admin
from . models import Donation_List, DonationType

# Register your models here.
admin.site.register(Donation_List)
admin.site.register(DonationType)
