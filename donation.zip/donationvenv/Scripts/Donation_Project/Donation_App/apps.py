from django.apps import AppConfig


class DonationAppConfig(AppConfig):
    name = 'Donation_App'
