from django.db import models
from django.utils import timezone

# Create your models here.


class Donation(models.Model):
    name = models.CharField(max_length=100)
    date = models.DateField(blank=True, null=True)
    amount = models.DecimalField(max_digits=13, decimal_places=2)
    donationType = models.CharField(max_length=50)

    def transaction(self):
        self.date = timezone.now()
        self.save()

    def __str__(self):
        return self.name


class DonationType(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name
